## CONTROL DE VERSIONES

Los sistemas más conocidos dentro del control de versiones son:

- CVS
- Subversion
- Mercurial
- **Git**

El mas conocido de los mencionados antes es Git, el cual posee unas caracteristicas como son:

- Es moderno
- Es distribuido
- Es eficiente

Dentro de GIT también obtenemos unos conceptos que debemos aprender y tener en cuenta a la hora de su realización. Estos conceptos son varios y se pueden clasificar en:

- Repository (local y remote)
- Commit
- Branch
  - [ ] Checkout
  - [ ] Merge

En GIT encontramos áreas diferentes que se pueden nombrar por:

- Working directory
- Staging area
- Repository

Para poder movernos de uno a otro deberemos utilizar comandos dentro de GIT como pueden ser **git add** para desplazarnos del working directory al staging area o **git commit** para desplazarnos de staging area a repository.



Aqui encontramos un ejemplo de las áreas

![Git areas](http://jamj2000.github.io/entornosdesarrollo/4/assets/git-areas2.png)

Dentro de GIT nos podemos encontrar tambien con las ramas que son lineas de tiempo en nuestro proyecto que nos sirven para aareglar errores, experimentar, hacer grandes cambios, etc.

Aqui mostramos un ejemplo de ramas

![Git areas](http://jamj2000.github.io/entornosdesarrollo/4/assets/git-branches.png)

Para terminar con este tema nombraremos aquellos sitios que soportan GIT

- GitHub
- Bitbucket
- GitLab
- Coding -en chino- 



### *Actividades Tema*

**1.Además de Git, ¿que otros sistemas de control de versiones existen?**

Existen otros sistemas como son CVS, Subversion y Mercurial



**2.En Git, ¿qué tres áreas existen?**

 Existen el working directory, el staging area y el repository



**4.Busca en Internet un buen tutorial de GIT y realízalo. ¿De qué tutorial se trata?**

https://www.atlassian.com/es/git

Este es el tutorial de GIT que he encontrado donde podemos ver teoria escrita y videos. Nos viene todo explicado por partes y explicando cada configuracion de GIT.



**5.En Git, ¿para qué sirve el comando `git config`?** 

El comando git config sirve para definir valores de configuración a nivel de un proyecto



**6.En Git, ¿para qué sirve el comando `git init`?** 

El comando git init sirve para crear un nuevo repositorio



**7.En Git, ¿para qué sirve el comando `git clone`?** 

El comando git clone se utiliza para apuntar a un repositorio existente y clonar o copiar dicho  repositorio en un nuevo directorio en otra ubicación.



**8.En Git, ¿para qué sirve el comando `git status`?** 

El comando git status muestra el estado del directorio de trabajo y del área del entorno de ensayo



**9.En Git, ¿para qué sirve el comando git add?**

El comando git add añade un cambio del directorio de trabajo en el entorno de ensayo.



**10.En Git, ¿para qué sirve el comando git commit?**

El comando git commit sirve para confirmar una instantánea del directorio del entorno de ensayo en el historial de confirmaciones de los repositorios.



**11.En Git, ¿para qué sirve el comando git log?**

El comando git log es una herramienta utlizada para explorar el historial del repositorio



**12.En Git, ¿para qué sirve el comando git reset HEAD nombrearchivo?**

El comando git reset HEAD sirve para restablecer el HEAD actual en un estado especifico



**13.En Git, ¿para qué sirve el comando git checkout -- nombrearchivo?**

El comando git checkout te permite desplazarte entre las ramas creadas por git branch 



**15.En Git, ¿para qué sirve el comando `git branch`?** 

El comando git branch nos permite crear, enumerar y eliminar ramas, así como cambiar su nombre.



**16.En Git, ¿para qué sirve el comando `git checkout`?** 

El comando git checkout nos permite desplazarnos entre las ramas creadas por git branch .



**17.En Git, ¿para qué sirve el comando `git merge`?** 

El comando git merge nos permite tomar las líneas independientes de desarrollo creadas por git branch e integrarlas en una sola rama. 



**18.En Git, explica cómo funciona la fusión (merge) de tipo fast-forward.**

Fast Forward en Git Merge puede definirse como una opción de gran utilidad y eficiencia para acelerar el flujo de trabajo en el proceso del proyecto. Esto lo consigue mediante la armonización de la rama principal del  proyecto, con las modificaciones resultantes de la creación de una rama *`feature`* con determinadas especificaciones de cambios.

Esta opción también se conoce como avance rápido o por sus siglas, FF (Fast Forward) en Git Merge, y destaca por su capacidad de cambiar el  \*HEAD\* en el sistema.



**19.En Git, explica cómo funciona la fusión (merge) de tipo 3-way.**

 Cuando no hay un proceso lineal hacia la rama de destino, Git no tiene  más opción que combinarlas mediante una fusión de 3 vías. Las fusiones  de 3 vías utilizan una confirmación específica para unir dos  historiales.
